
/*!
***************************************************************************
*
* \file symbol.c
*
* \brief
*    Generic Symbol writing interface
*
* \date
*    18 Jan 2006
*
* \author
*    Karsten Suehring
**************************************************************************/

#include "global.h"
#include "symbol.h"
